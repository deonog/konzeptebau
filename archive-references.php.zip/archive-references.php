<?php 
/*
	Template Name: Archive References
*/
?>
<?php get_header(); ?>

<?php get_footer(); ?>